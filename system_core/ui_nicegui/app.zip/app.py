from __future__ import annotations

from pathlib import Path
from typing import Any
import argparse
import logging
import os
import re
import shutil
import socket
import subprocess
import sys
import time
import webbrowser

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from nicegui import app as nicegui_app, run, ui  # type: ignore


def tolerate_missing_process_pool() -> None:
    """Keep NiceGUI alive when multiprocessing is blocked by the environment."""
    try:
        import nicegui.run as nicegui_run  # type: ignore
    except Exception:
        return

    original_setup = getattr(nicegui_run, "setup", None)
    if not callable(original_setup):
        return

    def safe_setup() -> None:
        try:
            original_setup()
        except (OSError, PermissionError) as exc:
            logging.warning("NiceGUI process pool disabled: %s", exc)
            nicegui_run.process_pool = None

    nicegui_run.setup = safe_setup


tolerate_missing_process_pool()


MAIN_PY = ROOT / "system_core" / "main.py"
DOCTOR_PY = ROOT / "system_core" / "doctor.py"
GUI_SETTINGS_PATH = ROOT / "config" / "gui_settings.yaml"
UI_COLORS_PATH = ROOT / "config" / "ui_colors.yaml"
TOOL_MANIFEST_PATH = ROOT / "config" / "tool_manifest.yaml"
PROGRESS_RE = re.compile(r"\[(\d+)/(\d+)\]")

FOLDERS = {
    "input": ROOT / "input",
    "output": ROOT / "output",
    "config": ROOT / "config",
    "logs": ROOT / "logs",
    "report": ROOT / "report",
    "release": ROOT / "release",
    "convert_cache": ROOT / "._runtime" / "convert_cache",
}

TRANSLATIONS = {
    "ru": {
        "subtitle": "GUI-shell поверх существующего CLI",
        "cancel": "Отменить",
        "workspace": "Рабочие папки",
        "operations": "Операции",
        "conversion_group": "КОНВЕРТАЦИЯ",
        "convert_mode": "Конвертировать...",
        "convert_setup": "Конвертация документов",
        "crop_pdf_group": "ОБРЕЗАТЬ PDF",
        "crop_pdf_mode": "Обрезать PDF...",
        "crop_pdf_setup": "Обрезка PDF",
        "crop_pptx_setup": "Обрезка PPTX",
        "crop_pdf_manual_setup": "PDF: обработка",
        "repeat_crop": "Повторить для уже обрезанных",
        "pdf_crop_action": "Что сделать с PDF",
        "add_pdf_group": "ИЗМЕНИТЬ PDF",
        "add_pdf_mode": "Изменить PDF...",
        "add_pdf_setup": "Изменение PDF",
        "page_numbers_setup": "Нумерация страниц",
        "scale_pdf_setup": "Уменьшить PDF",
        "split_vertical": "Разрезать по вертикали 50/50",
        "split_horizontal": "Разрезать по горизонтали 50/50",
        "skip_cover": "Разрезать все кроме обложки",
        "skip_cover_hint": "Для 50/50: первая и последняя страницы останутся целыми.",
        "crop_margins": "Обрезать поля",
        "aspect_crop": "Кадрирование",
        "aspect_none": "Не обрезать",
        "aspect_16_9": "Обрезать 16:9",
        "aspect_a_series": "Обрезать под A4/A3",
        "post_crop": "Обрезка презентаций после конвертации",
        "post_scale": "Уменьшить содержимое презентаций после конвертации",
        "scale_none": "Не уменьшать",
        "scale_percent": "Уменьшить до процента",
        "scale_percent_field": "Процент",
        "scale_pdf_content": "Уменьшить содержимое PDF",
        "left_mm": "Слева, мм",
        "right_mm": "Справа, мм",
        "top_mm": "Сверху, мм",
        "bottom_mm": "Снизу, мм",
        "page_numbers": "Колонтитул нумерации страниц",
        "start_page": "С какой страницы",
        "start_number": "С какого номера",
        "offset_mm": "От края, мм",
        "position": "Расположение",
        "run": "Запустить",
        "convert_file": "Конвертировать файл",
        "file_path": "Путь к Office-файлу",
        "source_folder": "Папка-источник",
        "destination_folder": "Папка-приёмник",
        "target_folder": "Целевая папка...",
        "add_folders": "Добавить папки...",
        "add": "Добавить...",
        "cache_ready": "Кэш источников: {count}",
        "cache_empty": "Кэш источников пуст",
        "status": "Статус",
        "log": "Журнал операции",
        "idle": "Ожидание",
        "running": "Выполняется",
        "done": "Готово",
        "error": "Ошибка",
        "another_running": "Другая операция уже выполняется.",
        "file_required": "Укажите путь к Office-файлу.",
        "source_required": "Укажите папку-источник.",
        "destination_required": "Укажите папку-приёмник.",
        "folder_only": "В этом поле нужна папка, не файл.",
        "operation_done": "Операция завершена.",
        "operation_failed": "Операция завершилась с кодом {code}.",
        "language": "Язык",
        "theme": "Тема",
        "dark": "Темная",
        "light": "Светлая",
        "language_saved": "Язык сохранен. Перезагружаю интерфейс.",
        "theme_saved": "Тема сохранена. Перезагружаю интерфейс.",
        "open": "Открыть",
        "add_files": "Добавить файлы...",
        "add_folder": "Добавить папку...",
        "clear_io": "Очистить I/O",
        "confirm_title": "Подтвердите действие",
        "confirm_cleanup_io": "Удалить содержимое input и output? Папки останутся на месте.",
        "choose_options": "Параметры запуска",
        "no_options_selected": "Выберите хотя бы один пункт.",
        "back": "Назад",
        "stage_files": "Добавление файлов в input",
        "stage_folder": "Добавление папки в input",
        "stage_convert_cache": "Добавление в кэш конвертации",
        "stage_target_folder": "Выбор целевой папки",
        "stage_cleanup_io": "Очистка input/output",
        "picker_cancelled": "Выбор отменен.",
        "expand_log": "Развернуть",
        "report": "Report",
        "close": "Закрыть",
        "lang_switch": "EN",
    },
    "en": {
        "subtitle": "GUI shell over the existing CLI",
        "cancel": "Cancel",
        "workspace": "Workspace folders",
        "operations": "Operations",
        "conversion_group": "CONVERSION",
        "convert_mode": "Convert...",
        "convert_setup": "Document conversion",
        "crop_pdf_group": "CROP PDF",
        "crop_pdf_mode": "Crop PDF...",
        "crop_pdf_setup": "PDF crop",
        "crop_pptx_setup": "PowerPoint PDF crop",
        "crop_pdf_manual_setup": "PDF tools",
        "repeat_crop": "Repeat for already cropped files",
        "pdf_crop_action": "PDF action",
        "add_pdf_group": "EDIT PDF",
        "add_pdf_mode": "Edit PDF...",
        "add_pdf_setup": "PDF editing",
        "page_numbers_setup": "Page numbering",
        "scale_pdf_setup": "Scale PDF",
        "split_vertical": "Split vertically 50/50",
        "split_horizontal": "Split horizontally 50/50",
        "skip_cover": "Split all except cover",
        "skip_cover_hint": "For 50/50 split: first and last pages stay unchanged.",
        "crop_margins": "Crop margins",
        "aspect_crop": "Crop aspect",
        "aspect_none": "Do not crop",
        "aspect_16_9": "Crop to 16:9",
        "aspect_a_series": "Crop to A4/A3",
        "post_crop": "Crop presentations after conversion",
        "post_scale": "Scale presentation contents after conversion",
        "scale_none": "Do not scale",
        "scale_percent": "Scale to percent",
        "scale_percent_field": "Percent",
        "scale_pdf_content": "Scale PDF content",
        "left_mm": "Left, mm",
        "right_mm": "Right, mm",
        "top_mm": "Top, mm",
        "bottom_mm": "Bottom, mm",
        "page_numbers": "Page number footer/header",
        "start_page": "Start page",
        "start_number": "Start number",
        "offset_mm": "Edge offset, mm",
        "position": "Position",
        "run": "Run",
        "convert_file": "Convert file",
        "file_path": "Office file path",
        "source_folder": "Source folder",
        "destination_folder": "Destination folder",
        "target_folder": "Target folder...",
        "add_folders": "Add folders...",
        "add": "Add...",
        "cache_ready": "Source cache: {count}",
        "cache_empty": "Source cache is empty",
        "status": "Status",
        "log": "Operation log",
        "idle": "Idle",
        "running": "Running",
        "done": "Done",
        "error": "Error",
        "another_running": "Another operation is already running.",
        "file_required": "Office file path is required.",
        "source_required": "Source folder is required.",
        "destination_required": "Destination folder is required.",
        "folder_only": "This field accepts a folder, not a file.",
        "operation_done": "Operation finished.",
        "operation_failed": "Operation finished with exit code {code}.",
        "language": "Language",
        "theme": "Theme",
        "dark": "Dark",
        "light": "Light",
        "language_saved": "Language saved. Reloading UI.",
        "theme_saved": "Theme saved. Reloading UI.",
        "open": "Open",
        "add_files": "Add files...",
        "add_folder": "Add folder...",
        "clear_io": "Clear I/O",
        "confirm_title": "Confirm action",
        "confirm_cleanup_io": "Delete contents of input and output? The folders stay in place.",
        "choose_options": "Run options",
        "no_options_selected": "Select at least one item.",
        "back": "Back",
        "stage_files": "Adding files to input",
        "stage_folder": "Adding folder to input",
        "stage_convert_cache": "Adding to conversion cache",
        "stage_target_folder": "Choosing target folder",
        "stage_cleanup_io": "Cleaning input/output",
        "picker_cancelled": "Selection cancelled.",
        "expand_log": "Expand",
        "report": "Report",
        "close": "Close",
        "lang_switch": "RU",
    },
}


def expand_arg(value: Any) -> str:
    text = str(value)
    return (
        text.replace("{MAIN_PY}", str(MAIN_PY))
        .replace("{DOCTOR_PY}", str(DOCTOR_PY))
        .replace("{ROOT}", str(ROOT))
    )


def normalize_option_choice(item: dict[str, Any]) -> dict[str, Any]:
    label = str(item.get("label", item.get("id", ""))).strip()
    return {
        "id": str(item.get("id", "")).strip(),
        "label_en": label,
        "label_ru": str(item.get("label_ru", label)).strip(),
        "value": str(item.get("value", "")).strip(),
        "default": bool(item.get("default", False)),
    }


def normalize_option_group(item: dict[str, Any]) -> dict[str, Any]:
    title = str(item.get("title", item.get("id", ""))).strip()
    description = str(item.get("description", "")).strip()
    choices = item.get("choices", [])
    args_prefix = item.get("args_prefix", [])
    if not isinstance(choices, list):
        choices = []
    if not isinstance(args_prefix, list):
        args_prefix = []
    return {
        "id": str(item.get("id", "")).strip(),
        "type": str(item.get("type", "checkboxes")).strip(),
        "title_en": title,
        "title_ru": str(item.get("title_ru", title)).strip(),
        "description_en": description,
        "description_ru": str(item.get("description_ru", description)).strip(),
        "min_selected": int(item.get("min_selected", 0) or 0),
        "args_prefix": [expand_arg(arg) for arg in args_prefix],
        "separator": str(item.get("separator", ",")),
        "choices": [
            choice
            for choice in (normalize_option_choice(choice) for choice in choices if isinstance(choice, dict))
            if choice["id"] and choice["value"]
        ],
    }


def normalize_operation(item: dict[str, Any]) -> dict[str, Any]:
    title = str(item.get("title", item.get("title_en", item.get("id", "")))).strip()
    description = str(item.get("description", item.get("description_en", ""))).strip()
    args = item.get("args", [])
    language_args = item.get("language_args", {})
    option_groups = item.get("option_groups", [])
    if not isinstance(args, list):
        args = []
    if not isinstance(language_args, dict):
        language_args = {}
    if not isinstance(option_groups, list):
        option_groups = []
    return {
        "id": str(item.get("id", "")).strip(),
        "title_en": title,
        "title_ru": str(item.get("title_ru", title)).strip(),
        "description_en": description,
        "description_ru": str(item.get("description_ru", description)).strip(),
        "args": [expand_arg(arg) for arg in args],
        "language_args": {
            str(lang): [expand_arg(arg) for arg in values]
            for lang, values in language_args.items()
            if isinstance(values, list)
        },
        "option_groups": [
            group
            for group in (normalize_option_group(group) for group in option_groups if isinstance(group, dict))
            if group["id"] and group["choices"]
        ],
        "needs_file": bool(item.get("needs_file", False)),
    }


def load_tool_manifest() -> tuple[dict[str, Any], list[str], list[str]]:
    if not TOOL_MANIFEST_PATH.exists():
        raise RuntimeError(f"Tool manifest was not found: {TOOL_MANIFEST_PATH}")
    try:
        import yaml  # type: ignore
    except Exception as exc:
        raise RuntimeError("PyYAML is required to read tool_manifest.yaml.") from exc

    raw = yaml.safe_load(TOOL_MANIFEST_PATH.read_text(encoding="utf-8")) or {}
    if not isinstance(raw, dict):
        raise RuntimeError(f"Tool manifest must contain a mapping: {TOOL_MANIFEST_PATH}")

    operations: dict[str, dict[str, Any]] = {}
    main_ids: list[str] = []
    file_ids: list[str] = []

    for section_name, id_bucket in (("operations", main_ids), ("file_operations", file_ids)):
        items = raw.get(section_name, [])
        if not isinstance(items, list):
            continue
        for item in items:
            if not isinstance(item, dict):
                continue
            operation = normalize_operation(item)
            if not operation["id"]:
                continue
            operations[operation["id"]] = operation
            id_bucket.append(operation["id"])

    return operations, main_ids, file_ids


OPERATIONS, MAIN_OPERATION_IDS, FILE_OPERATION_IDS = load_tool_manifest()

PICKER_BOOTSTRAP = r"""
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
try {
  Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class AudionDpiAwareness {
  [DllImport("user32.dll")]
  public static extern bool SetProcessDpiAwarenessContext(IntPtr dpiContext);
  [DllImport("shcore.dll")]
  public static extern int SetProcessDpiAwareness(int value);
}
"@
  try { [AudionDpiAwareness]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null }
  catch { [AudionDpiAwareness]::SetProcessDpiAwareness(2) | Out-Null }
} catch {}
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()
"""

state: dict[str, Any] = {
    "running": False,
    "cancel": False,
    "progress": 0.0,
    "status": "",
    "lines": [],
    "log_version": 0,
    "exit_code": None,
    "convert_cache_dir": "",
    "convert_cache_count": 0,
    "active_module": "root",
    "command_screen": "main",
    "crop_pdf_screen": "main",
    "add_pdf_screen": "main",
}

DEFAULT_THEME_ID = "code_dark"
THEME_ALIASES = {"dark": "code_dark", "light": "code_light"}

DEFAULT_THEME_TOKENS: dict[str, str] = {
    "color-background-primary": "#141413",
    "color-background-secondary": "#1f1e1a",
    "color-background-tertiary": "#0f0f0e",
    "color-text-primary": "#faf9f5",
    "color-text-secondary": "#e8e6dc",
    "color-text-tertiary": "#b0aea5",
    "color-border-tertiary": "rgba(250, 249, 245, 0.15)",
    "color-border-secondary": "rgba(250, 249, 245, 0.3)",
    "color-border-primary": "rgba(250, 249, 245, 0.4)",
    "color-accent-primary": "#d97757",
    "font-sans": "Inter, Segoe UI, Arial, sans-serif",
    "font-mono": "Cascadia Mono, Consolas, monospace",
    "border-radius-md": "8px",
    "border-radius-lg": "12px",
}

DEFAULT_THEME_DATA: dict[str, Any] = {
    "label": "Code Dark",
    "label_ru": "Code Темная",
    "mode": "dark",
    "tokens": dict(DEFAULT_THEME_TOKENS),
}

settings: dict[str, Any] = {
    "language": "ru",
    "theme": DEFAULT_THEME_ID,
    "emoji": False,
}


def _string_map(value: Any) -> dict[str, str]:
    if not isinstance(value, dict):
        return {}
    return {str(key).strip(): str(item).strip() for key, item in value.items() if str(key).strip()}


def _load_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        import yaml  # type: ignore

        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def load_ui_colors(path: Path) -> dict[str, Any]:
    data = _load_yaml(path)
    themes: dict[str, dict[str, Any]] = {}
    themes_raw = data.get("themes", {})
    if not isinstance(themes_raw, dict):
        themes_raw = {}
    for theme_id, theme_data in themes_raw.items():
        if not isinstance(theme_data, dict):
            continue
        normalized_id = str(theme_id).strip().lower()
        if not normalized_id:
            continue
        themes[normalized_id] = {
            "label": str(theme_data.get("label") or normalized_id).strip(),
            "label_ru": str(theme_data.get("label_ru") or theme_data.get("label") or normalized_id).strip(),
            "mode": "dark" if str(theme_data.get("mode", "dark")).lower() == "dark" else "light",
            "tokens": _string_map(theme_data.get("tokens", {})),
        }
    if DEFAULT_THEME_ID not in themes:
        themes[DEFAULT_THEME_ID] = dict(DEFAULT_THEME_DATA)
    return {
        "ramps": data.get("ramps", {}) if isinstance(data.get("ramps", {}), dict) else {},
        "tokens": _string_map(data.get("tokens", {})),
        "themes": themes,
    }


ui_colors = load_ui_colors(UI_COLORS_PATH)


def normalize_theme_id(theme_id: Any) -> str:
    text = str(theme_id or DEFAULT_THEME_ID).strip().lower()
    cleaned = "".join(char for char in text if char.isalnum() or char in {"_", "-"})
    return THEME_ALIASES.get(cleaned, cleaned or DEFAULT_THEME_ID)


def active_theme() -> str:
    theme_id = normalize_theme_id(settings.get("theme", DEFAULT_THEME_ID))
    themes = ui_colors["themes"]
    if theme_id in themes:
        return theme_id
    return DEFAULT_THEME_ID if DEFAULT_THEME_ID in themes else next(iter(themes))


def active_theme_data() -> dict[str, Any]:
    return dict(ui_colors["themes"][active_theme()])


def active_theme_mode() -> str:
    return str(active_theme_data().get("mode", "dark"))


def theme_label(theme_id: str) -> str:
    theme_data = ui_colors["themes"].get(theme_id, {})
    label_key = "label_ru" if settings.get("language") == "ru" else "label"
    return str(theme_data.get(label_key) or theme_data.get("label") or theme_id)


def theme_options() -> dict[str, str]:
    return {theme_id: theme_label(theme_id) for theme_id in ui_colors["themes"]}


def theme_variables() -> dict[str, str]:
    variables: dict[str, str] = {}
    for ramp_name, stops in ui_colors["ramps"].items():
        if not isinstance(stops, dict):
            continue
        for stop, color in stops.items():
            variables[f"color-{ramp_name}-{stop}"] = str(color).strip()
    variables.update(DEFAULT_THEME_TOKENS)
    variables.update(ui_colors["tokens"])
    variables.update(_string_map(active_theme_data().get("tokens", {})))
    return variables


def set_theme(theme_id: Any) -> None:
    selected = normalize_theme_id(theme_id)
    if selected not in ui_colors["themes"]:
        return
    settings["theme"] = selected
    save_settings()
    safe_notify(tr("theme_saved"), type="positive")
    ui.run_javascript("window.location.reload()")


def theme_change_handler(event: Any) -> None:
    set_theme(getattr(event, "value", None))


def load_settings() -> None:
    data = _load_yaml(GUI_SETTINGS_PATH)
    ui_data = data.get("gui", data) if isinstance(data, dict) else {}
    if not isinstance(ui_data, dict):
        return
    language = str(ui_data.get("language", settings["language"])).strip().lower()
    theme = normalize_theme_id(ui_data.get("theme", settings["theme"]))
    if language in {"ru", "en"}:
        settings["language"] = language
    settings["theme"] = theme if theme in ui_colors["themes"] else DEFAULT_THEME_ID
    settings["emoji"] = bool(ui_data.get("emoji", settings["emoji"]))


def save_settings() -> None:
    GUI_SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
    text = (
        "gui:\n"
        "  # Change to \"en\" for public GitHub builds.\n"
        f"  language: \"{settings['language']}\"\n"
        f"  theme: \"{active_theme()}\"\n"
        f"  emoji: {str(bool(settings['emoji'])).lower()}\n"
    )
    GUI_SETTINGS_PATH.write_text(text, encoding="utf-8", newline="\n")


def tr(key: str, **kwargs: Any) -> str:
    text = TRANSLATIONS.get(settings["language"], TRANSLATIONS["en"]).get(key, key)
    return text.format(**kwargs) if kwargs else text


def safe_notify(message: str, **kwargs: Any) -> None:
    options = {"message": str(message), **kwargs}
    delivered = False
    for client in list(nicegui_app.clients()):
        if getattr(client, "_deleted", False) or not client.has_socket_connection:
            continue
        client.outbox.enqueue_message("notify", options, client.id)
        delivered = True
    if delivered:
        return

    try:
        ui.notify(message, **kwargs)
    except RuntimeError as exc:
        if "slot belongs to has been deleted" not in str(exc):
            raise
        logging.warning("NiceGUI notification skipped because no live client slot was available: %s", message)


def notify_operation_result(exit_code: int) -> None:
    safe_notify(
        tr("operation_done") if exit_code == 0 else tr("operation_failed", code=exit_code),
        type="positive" if exit_code == 0 else "negative",
    )


def page_number_position_options() -> dict[str, str]:
    if settings["language"] == "ru":
        return {
            "bottom-right": "снизу справа",
            "bottom-center": "снизу по центру",
            "bottom-left": "снизу слева",
            "top-right": "сверху справа",
            "top-center": "сверху по центру",
            "top-left": "сверху слева",
        }
    return {
        "bottom-right": "bottom right",
        "bottom-center": "bottom center",
        "bottom-left": "bottom left",
        "top-right": "top right",
        "top-center": "top center",
        "top-left": "top left",
    }


def em(key: str) -> str:
    if not bool(settings.get("emoji", False)):
        return ""
    return {
        "workspace": "📁 ",
        "operations": "⚙ ",
        "conversion": "🔁 ",
        "crop_pdf": "✂️ ",
        "add_pdf": "🛠️ ",
        "status": "● ",
        "log": "🖥 ",
    }.get(key, "")


def op_text(operation_id: str, field: str) -> str:
    operation = OPERATIONS[operation_id]
    return str(operation.get(f"{field}_{settings['language']}") or operation.get(f"{field}_en") or operation_id)


def localized_text(item: dict[str, Any], field: str) -> str:
    return str(item.get(f"{field}_{settings['language']}") or item.get(f"{field}_en") or item.get(field) or "")


def ensure_dirs() -> None:
    for folder in [*FOLDERS.values(), ROOT / "config"]:
        folder.mkdir(parents=True, exist_ok=True)


def add_log(message: str) -> None:
    if not message.strip():
        return
    line = message.rstrip()
    state["lines"].append(line)
    state["lines"] = state["lines"][-500:]
    state["log_version"] = int(state["log_version"]) + 1
    match = PROGRESS_RE.search(line)
    if match and line.startswith(("[OK]", "[FAIL]")):
        index = int(match.group(1))
        total = max(1, int(match.group(2)))
        state["progress"] = max(float(state["progress"]), min(0.98, index / total))


def progress_text() -> str:
    return f"{round(max(0.0, min(1.0, float(state['progress']))) * 100):.0f}%"


def status_dot_classes() -> str:
    base = "audion-status-dot text-lg leading-none"
    if bool(state["running"]):
        return f"{base} text-sky-400 animate-pulse"
    if state.get("exit_code") is None:
        return f"{base} text-gray-500"
    if int(state.get("exit_code") or 0) == 0:
        return f"{base} text-green-400"
    return f"{base} text-red-400"


def hidden_startupinfo() -> subprocess.STARTUPINFO | None:
    if os.name != "nt" or not hasattr(subprocess, "STARTUPINFO"):
        return None
    startupinfo = subprocess.STARTUPINFO()
    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startupinfo.wShowWindow = 0
    return startupinfo


def hidden_subprocess_flags() -> int:
    if os.name == "nt" and hasattr(subprocess, "CREATE_NO_WINDOW"):
        return int(subprocess.CREATE_NO_WINDOW)
    return 0


def hidden_subprocess_kwargs() -> dict[str, Any]:
    kwargs: dict[str, Any] = {}
    startupinfo = hidden_startupinfo()
    if startupinfo is not None:
        kwargs["startupinfo"] = startupinfo
    creationflags = hidden_subprocess_flags()
    if creationflags:
        kwargs["creationflags"] = creationflags
    return kwargs


def resolve_dialog_powershell() -> list[str]:
    candidates = [
        [str(ROOT / "system_core" / "powershell" / "pwsh.exe"), "-NoLogo", "-NoProfile", "-STA", "-WindowStyle", "Hidden", "-Command"],
        ["pwsh.exe", "-NoLogo", "-NoProfile", "-STA", "-WindowStyle", "Hidden", "-Command"],
        ["powershell.exe", "-NoProfile", "-STA", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-Command"],
    ]
    for candidate in candidates:
        exe = candidate[0]
        if Path(exe).exists() or shutil.which(exe):
            return candidate
    raise RuntimeError("PowerShell was not found for Windows picker.")


def pick_files() -> list[Path]:
    script = PICKER_BOOTSTRAP + r"""
$dialog = New-Object System.Windows.Forms.OpenFileDialog
$dialog.Title = 'Add files to input'
$dialog.Multiselect = $true
$dialog.Filter = 'Office files|*.doc;*.docx;*.docm;*.rtf;*.txt;*.odt;*.xls;*.xlsx;*.xlsm;*.xlsb;*.csv;*.ods;*.ppt;*.pptx;*.pptm;*.odp|All files|*.*'
if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
  $dialog.FileNames | ConvertTo-Json -Compress
}
"""
    result = subprocess.run(
        [*resolve_dialog_powershell(), script],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=3600,
        **hidden_subprocess_kwargs(),
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "File picker failed.")
    return parse_picker_paths(result.stdout)


def pick_folder(title: str = "Add folder to input") -> list[Path]:
    safe_title = title.replace("'", "''")
    script = PICKER_BOOTSTRAP + """
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = '__AUDION_FOLDER_DIALOG_TITLE__'
$dialog.ShowNewFolderButton = $false
if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
  @($dialog.SelectedPath) | ConvertTo-Json -Compress
}
""".replace("__AUDION_FOLDER_DIALOG_TITLE__", safe_title)
    result = subprocess.run(
        [*resolve_dialog_powershell(), script],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=3600,
        **hidden_subprocess_kwargs(),
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "Folder picker failed.")
    return parse_picker_paths(result.stdout)


def parse_picker_paths(text: str) -> list[Path]:
    import json

    payload = text.strip()
    if not payload:
        return []
    data = json.loads(payload)
    if isinstance(data, str):
        data = [data]
    return [Path(str(item)).resolve() for item in data if str(item).strip()]


def unique_target(path: Path) -> Path:
    if not path.exists():
        return path
    stem = path.stem
    suffix = path.suffix
    for index in range(2, 1000):
        candidate = path.with_name(f"{stem}_{index}{suffix}")
        if not candidate.exists():
            return candidate
    raise RuntimeError(f"Could not allocate a unique target name for {path.name}")


def copy_item_to_input(source: Path) -> Path:
    input_dir = FOLDERS["input"]
    input_dir.mkdir(parents=True, exist_ok=True)
    source_resolved = source.resolve()
    input_resolved = input_dir.resolve()

    if source_resolved == input_resolved:
        raise RuntimeError("Cannot import the input folder into itself.")
    if input_resolved.is_relative_to(source_resolved):
        raise RuntimeError(f"Cannot import a parent folder of input: {source}")
    if source_resolved.is_relative_to(input_resolved):
        add_log(f"SKIP already in input -> {source}")
        return source

    target = unique_target(input_dir / source.name)
    if source.is_dir():
        shutil.copytree(source, target)
        return target
    if source.is_file():
        shutil.copy2(source, target)
        return target
    raise RuntimeError(f"Unsupported source path: {source}")


def active_convert_cache_dir() -> Path:
    cache_dir = str(state.get("convert_cache_dir") or "").strip()
    if cache_dir:
        path = Path(cache_dir)
    else:
        path = FOLDERS["convert_cache"] / time.strftime("cache_%Y%m%d_%H%M%S")
        state["convert_cache_dir"] = str(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def copy_item_to_convert_cache(source: Path) -> Path:
    cache_dir = active_convert_cache_dir()
    source_resolved = source.resolve()
    cache_resolved = cache_dir.resolve()

    if source_resolved == cache_resolved:
        raise RuntimeError("Cannot import the conversion cache into itself.")
    if cache_resolved.is_relative_to(source_resolved):
        raise RuntimeError(f"Cannot import a parent folder of the conversion cache: {source}")
    if source_resolved.is_relative_to(cache_resolved):
        add_log(f"SKIP already in conversion cache -> {source}")
        return source

    target = unique_target(cache_dir / source.name)
    if source.is_dir():
        shutil.copytree(source, target)
        return target
    if source.is_file():
        shutil.copy2(source, target)
        return target
    raise RuntimeError(f"Unsupported source path: {source}")


def import_to_convert_cache(kind: str) -> tuple[int, str]:
    sources = pick_files() if kind == "files" else pick_folder(tr("add_folders"))
    if not sources:
        add_log(tr("picker_cancelled"))
        return 0, str(state.get("convert_cache_dir") or "")

    total = len(sources)
    for index, source in enumerate(sources, start=1):
        if state["cancel"]:
            add_log("Cancellation requested.")
            return 2, str(state.get("convert_cache_dir") or "")
        target = copy_item_to_convert_cache(source)
        add_log(f"[{index}/{total}] CACHED -> {target}")
        state["progress"] = index / max(1, total)
    state["convert_cache_count"] = int(state.get("convert_cache_count") or 0) + total
    return 0, str(active_convert_cache_dir())


def is_inside(child: Path, parent: Path) -> bool:
    try:
        child_resolved = str(child.resolve())
        parent_resolved = str(parent.resolve())
    except OSError:
        return False
    try:
        return os.path.commonpath([child_resolved, parent_resolved]) == parent_resolved
    except ValueError:
        return False


def clean_managed_folder(folder_id: str) -> tuple[int, list[str]]:
    folder = FOLDERS[folder_id]
    root = ROOT.resolve()
    if folder.is_symlink():
        raise RuntimeError(f"{folder_id} is a symbolic link. Cleanup blocked.")
    folder.mkdir(parents=True, exist_ok=True)
    folder_resolved = folder.resolve()
    if not is_inside(folder_resolved, root):
        raise RuntimeError(f"{folder_id} is outside project root. Cleanup blocked.")

    removed = 0
    skipped: list[str] = []
    for item in folder.iterdir():
        if item.name == ".gitkeep":
            continue
        try:
            if item.is_symlink():
                item.unlink()
            elif item.is_dir():
                if not is_inside(item, folder_resolved):
                    skipped.append(f"{item.name} (outside {folder_id})")
                    continue
                shutil.rmtree(item)
            else:
                item.unlink()
            removed += 1
            add_log(f"REMOVED {folder_id}: {item.name}")
        except OSError as exc:
            skipped.append(f"{item.name} ({exc})")
    return removed, skipped


def cleanup_input_output() -> int:
    add_log("Cleaning managed input/output folders.")
    removed_input, skipped_input = clean_managed_folder("input")
    state["progress"] = 0.5
    if state["cancel"]:
        add_log("Cleanup cancelled after input cleanup.")
        return 2
    removed_output, skipped_output = clean_managed_folder("output")
    skipped = [*skipped_input, *skipped_output]
    add_log(f"Input/output cleanup complete. Removed: {removed_input + removed_output}, skipped: {len(skipped)}")
    for item in skipped:
        add_log(f"SKIP cleanup: {item}")
    return 0


def import_to_input(kind: str) -> int:
    sources = pick_files() if kind == "files" else pick_folder()
    if not sources:
        add_log(tr("picker_cancelled"))
        return 0

    total = len(sources)
    for index, source in enumerate(sources, start=1):
        if state["cancel"]:
            add_log("Cancellation requested.")
            return 2
        target = copy_item_to_input(source)
        add_log(f"[{index}/{total}] COPIED -> {target}")
        state["progress"] = index / max(1, total)
    return 0


async def start_import(kind: str) -> None:
    if state["running"]:
        safe_notify(tr("another_running"), type="warning")
        return
    title = tr("stage_files") if kind == "files" else tr("stage_folder")
    state.update(
        {
            "running": True,
            "cancel": False,
            "progress": 0.02,
            "status": f"{tr('running')}: {title}",
            "lines": [],
            "log_version": int(state["log_version"]) + 1,
            "exit_code": None,
        }
    )
    try:
        exit_code = await run.io_bound(import_to_input, kind)
        state["exit_code"] = exit_code
        state["progress"] = 1.0
        state["status"] = f"{tr('done')}: {title} [{exit_code}]"
        notify_operation_result(exit_code)
    except Exception as exc:
        state["exit_code"] = 1
        state["progress"] = max(float(state["progress"]), 0.98)
        state["status"] = f"{tr('error')}: {exc}"
        add_log(f"ERROR: {exc.__class__.__name__}: {exc}")
        safe_notify(str(exc), type="negative")
    finally:
        state["running"] = False


async def confirm_cleanup_input_output() -> None:
    if state["running"]:
        safe_notify(tr("another_running"), type="warning")
        return

    with ui.dialog() as dialog, ui.card().classes("rounded-lg"):
        ui.label(tr("confirm_title")).classes("text-base font-semibold")
        ui.label(tr("confirm_cleanup_io")).classes("text-sm text-gray-400")
        with ui.row().classes("gap-2"):
            ui.button(tr("cancel"), on_click=dialog.close).props("dense flat")
            ui.button(tr("clear_io"), on_click=lambda: dialog.submit(True)).props("dense color=negative")
    confirmed = await dialog
    if not confirmed:
        return

    title = tr("stage_cleanup_io")
    state.update(
        {
            "running": True,
            "cancel": False,
            "progress": 0.02,
            "status": f"{tr('running')}: {title}",
            "lines": [],
            "log_version": int(state["log_version"]) + 1,
            "exit_code": None,
        }
    )
    try:
        exit_code = await run.io_bound(cleanup_input_output)
        state["exit_code"] = exit_code
        state["progress"] = 1.0
        state["status"] = f"{tr('done')}: {title} [{exit_code}]"
        notify_operation_result(exit_code)
    except Exception as exc:
        state["exit_code"] = 1
        state["progress"] = max(float(state["progress"]), 0.98)
        state["status"] = f"{tr('error')}: {exc}"
        add_log(f"ERROR: {exc.__class__.__name__}: {exc}")
        safe_notify(str(exc), type="negative")
    finally:
        state["running"] = False


def build_option_args(operation: dict[str, Any], option_values: dict[str, list[str]] | None) -> list[str]:
    if not option_values:
        return []

    args: list[str] = []
    for group in operation.get("option_groups", []):
        if group.get("type") != "checkboxes":
            continue
        selected_ids = set(option_values.get(str(group["id"]), []))
        selected_values = [
            str(choice["value"])
            for choice in group.get("choices", [])
            if str(choice["id"]) in selected_ids
        ]
        min_selected = int(group.get("min_selected", 0) or 0)
        if len(selected_values) < min_selected:
            raise ValueError(tr("no_options_selected"))
        if not selected_values:
            continue
        args.extend(group.get("args_prefix", []))
        separator = str(group.get("separator", ","))
        if separator:
            args.append(separator.join(selected_values))
        else:
            args.extend(selected_values)
    return args


def build_command(operation_id: str, file_path: str, option_values: dict[str, list[str]] | None = None) -> list[str]:
    operation = OPERATIONS[operation_id]
    cmd = [sys.executable, "-u", *operation["args"]]
    cmd.extend(build_option_args(operation, option_values))
    language_args = operation.get("language_args", {})
    if isinstance(language_args, dict):
        cmd.extend(language_args.get(settings["language"], []))
    if operation.get("needs_file"):
        cleaned = file_path.strip().strip('"')
        if not cleaned:
            raise ValueError(tr("file_required"))
        cmd.append(cleaned)
    return cmd


def validate_folder_field(raw_path: str, required_message: str) -> Path:
    cleaned = raw_path.strip().strip('"')
    if not cleaned:
        raise ValueError(required_message)
    path = Path(cleaned).expanduser().resolve()
    if path.exists() and not path.is_dir():
        raise ValueError(f"{tr('folder_only')}: {path}")
    return path


def build_convert_command(
    source_dir: str,
    destination_dir: str,
    option_values: dict[str, list[str]] | None = None,
    post_crop: str = "none",
    post_scale_percent: float = 100.0,
) -> list[str]:
    source = validate_folder_field(source_dir, tr("source_required"))
    destination = validate_folder_field(destination_dir, tr("destination_required"))
    if not source.exists():
        raise ValueError(f"{tr('source_required')}: {source}")

    operation = OPERATIONS["batch_recursive"]
    cmd = [
        sys.executable,
        "-u",
        str(MAIN_PY),
        "batch",
        "--recursive",
        "--input-dir",
        str(source),
        "--output-dir",
        str(destination),
    ]
    cmd.extend(build_option_args(operation, option_values))
    if post_crop != "none":
        cmd.extend(["--post-crop", post_crop])
    if post_scale_percent < 100.0:
        cmd.extend(["--post-scale-percent", str(post_scale_percent)])
    return cmd


def run_process_command(cmd: list[str]) -> int:
    rendered = " ".join(f'"{part}"' if " " in part else part for part in cmd)
    add_log("RUN: " + rendered)

    env = os.environ.copy()
    env.setdefault("PYTHONUTF8", "1")
    env["PYTHONIOENCODING"] = "utf-8"
    process = subprocess.Popen(
        cmd,
        cwd=str(ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        env=env,
        **hidden_subprocess_kwargs(),
    )

    assert process.stdout is not None
    for line in process.stdout:
        if state["cancel"]:
            process.terminate()
            add_log("Cancellation requested.")
            break
        add_log(line)

    return process.wait()


def run_cli_operation(
    operation_id: str,
    file_path: str,
    option_values: dict[str, list[str]] | None = None,
) -> int:
    cmd = build_command(operation_id, file_path, option_values)
    return run_process_command(cmd)


def run_convert_operation(
    source_dir: str,
    destination_dir: str,
    option_values: dict[str, list[str]] | None = None,
    post_crop: str = "none",
    post_scale_percent: float = 100.0,
) -> int:
    cmd = build_convert_command(source_dir, destination_dir, option_values, post_crop, post_scale_percent)
    return run_process_command(cmd)


async def start_operation(
    operation_id: str,
    file_path: str = "",
    option_values: dict[str, list[str]] | None = None,
) -> None:
    if state["running"]:
        safe_notify(tr("another_running"), type="warning")
        return

    operation_title = op_text(operation_id, "title")
    state.update(
        {
            "running": True,
            "cancel": False,
            "progress": 0.02,
            "status": f"{tr('running')}: {operation_title}",
            "lines": [],
            "log_version": int(state["log_version"]) + 1,
            "exit_code": None,
        }
    )

    started = time.perf_counter()
    try:
        exit_code = await run.io_bound(run_cli_operation, operation_id, file_path, option_values)
        elapsed = time.perf_counter() - started
        state["exit_code"] = exit_code
        state["progress"] = 1.0
        state["status"] = f"{tr('done')}: {op_text(operation_id, 'title')} [{exit_code}] {elapsed:.1f}s"
        notify_operation_result(exit_code)
    except Exception as exc:
        state["exit_code"] = 1
        state["progress"] = max(float(state["progress"]), 0.98)
        state["status"] = f"{tr('error')}: {exc}"
        add_log(f"ERROR: {exc.__class__.__name__}: {exc}")
        safe_notify(str(exc), type="negative")
    finally:
        state["running"] = False


async def start_convert_operation(
    source_dir: str,
    destination_dir: str,
    option_values: dict[str, list[str]] | None = None,
    post_crop: str = "none",
    post_scale_percent: float = 100.0,
) -> None:
    if state["running"]:
        safe_notify(tr("another_running"), type="warning")
        return

    operation_title = tr("convert_mode")
    state.update(
        {
            "running": True,
            "cancel": False,
            "progress": 0.02,
            "status": f"{tr('running')}: {operation_title}",
            "lines": [],
            "log_version": int(state["log_version"]) + 1,
            "exit_code": None,
        }
    )

    started = time.perf_counter()
    try:
        exit_code = await run.io_bound(
            run_convert_operation,
            source_dir,
            destination_dir,
            option_values,
            post_crop,
            post_scale_percent,
        )
        elapsed = time.perf_counter() - started
        state["exit_code"] = exit_code
        state["progress"] = 1.0
        state["status"] = f"{tr('done')}: {operation_title} [{exit_code}] {elapsed:.1f}s"
        notify_operation_result(exit_code)
    except Exception as exc:
        state["exit_code"] = 1
        state["progress"] = max(float(state["progress"]), 0.98)
        state["status"] = f"{tr('error')}: {exc}"
        add_log(f"ERROR: {exc.__class__.__name__}: {exc}")
        safe_notify(str(exc), type="negative")
    finally:
        state["running"] = False


async def start_raw_cli_operation(title: str, cmd: list[str]) -> None:
    if state["running"]:
        safe_notify(tr("another_running"), type="warning")
        return
    state.update(
        {
            "running": True,
            "cancel": False,
            "progress": 0.02,
            "status": f"{tr('running')}: {title}",
            "lines": [],
            "log_version": int(state["log_version"]) + 1,
            "exit_code": None,
        }
    )
    started = time.perf_counter()
    try:
        exit_code = await run.io_bound(run_process_command, cmd)
        elapsed = time.perf_counter() - started
        state["exit_code"] = exit_code
        state["progress"] = 1.0
        state["status"] = f"{tr('done')}: {title} [{exit_code}] {elapsed:.1f}s"
        notify_operation_result(exit_code)
    except Exception as exc:
        state["exit_code"] = 1
        state["progress"] = max(float(state["progress"]), 0.98)
        state["status"] = f"{tr('error')}: {exc}"
        add_log(f"ERROR: {exc.__class__.__name__}: {exc}")
        safe_notify(str(exc), type="negative")
    finally:
        state["running"] = False


async def add_to_convert_cache(kind: str, source_input: Any, cache_label: Any) -> None:
    if state["running"]:
        safe_notify(tr("another_running"), type="warning")
        return
    title = tr("stage_convert_cache")
    state.update(
        {
            "running": True,
            "cancel": False,
            "progress": 0.02,
            "status": f"{tr('running')}: {title}",
            "lines": [],
            "log_version": int(state["log_version"]) + 1,
            "exit_code": None,
        }
    )
    try:
        exit_code, cache_dir = await run.io_bound(import_to_convert_cache, kind)
        state["exit_code"] = exit_code
        state["progress"] = 1.0
        state["status"] = f"{tr('done')}: {title} [{exit_code}]"
        try:
            if cache_dir:
                source_input.value = cache_dir
            count = int(state.get("convert_cache_count") or 0)
            cache_label.text = tr("cache_ready", count=count) if count else tr("cache_empty")
        except RuntimeError as exc:
            if "slot belongs to has been deleted" not in str(exc):
                raise
            logging.warning("Convert cache controls were skipped because their client slot was deleted.")
        notify_operation_result(exit_code)
    except Exception as exc:
        state["exit_code"] = 1
        state["progress"] = max(float(state["progress"]), 0.98)
        state["status"] = f"{tr('error')}: {exc}"
        add_log(f"ERROR: {exc.__class__.__name__}: {exc}")
        safe_notify(str(exc), type="negative")
    finally:
        state["running"] = False


async def choose_folder_into(field: Any, title: str) -> None:
    if state["running"]:
        safe_notify(tr("another_running"), type="warning")
        return
    try:
        folders = await run.io_bound(pick_folder, title)
    except Exception as exc:
        safe_notify(str(exc), type="negative")
        return
    if not folders:
        safe_notify(tr("picker_cancelled"), type="warning")
        return
    field.value = str(folders[0])


async def choose_operation_options(operation_id: str, file_path: str = "") -> None:
    operation = OPERATIONS[operation_id]
    groups = operation.get("option_groups", [])
    if not groups:
        await start_operation(operation_id, file_path)
        return

    group_controls: dict[str, dict[str, Any]] = {}

    with ui.dialog() as dialog, ui.card().classes("w-[520px] max-w-[92vw] rounded-lg p-4").style("background: var(--audion-panel-bg);"):
        ui.label(f"{tr('choose_options')}: {op_text(operation_id, 'title')}").classes("text-base font-semibold")
        for group in groups:
            group_id = str(group["id"])
            group_controls[group_id] = {}
            with ui.column().classes("w-full gap-1 border-t border-gray-800 pt-3"):
                ui.label(localized_text(group, "title")).classes("text-sm font-semibold")
                description = localized_text(group, "description")
                if description:
                    ui.label(description).classes("text-xs text-gray-400")
                with ui.row().classes("w-full flex-wrap gap-4 pt-1"):
                    for choice in group.get("choices", []):
                        checkbox = ui.checkbox(
                            localized_text(choice, "label"),
                            value=bool(choice.get("default", False)),
                        ).props("dense")
                        group_controls[group_id][str(choice["id"])] = checkbox

        def submit_options() -> None:
            selected: dict[str, list[str]] = {}
            for group in groups:
                group_id = str(group["id"])
                ids = [
                    choice_id
                    for choice_id, checkbox in group_controls.get(group_id, {}).items()
                    if bool(checkbox.value)
                ]
                if len(ids) < int(group.get("min_selected", 0) or 0):
                    safe_notify(tr("no_options_selected"), type="warning")
                    return
                selected[group_id] = ids
            dialog.submit(selected)

        with ui.row().classes("w-full justify-end gap-2 pt-3"):
            ui.button(tr("back"), on_click=dialog.close).props("dense flat")
            ui.button(tr("run"), on_click=submit_options).props("dense color=primary")

    selected_options = await dialog
    if selected_options is None:
        return
    await start_operation(operation_id, file_path, selected_options)


def open_folder(folder_id: str) -> None:
    folder = FOLDERS[folder_id]
    folder.mkdir(parents=True, exist_ok=True)
    if os.name == "nt":
        os.startfile(str(folder))  # type: ignore[attr-defined]
        return
    webbrowser.open(folder.as_uri())


def operation_button(operation_id: str, file_input: Any | None = None) -> None:
    with ui.element("div").classes("audion-operation-row"):
        ui.button(
            op_text(operation_id, "title"),
            on_click=lambda op=operation_id: choose_operation_options(op, str(file_input.value if file_input else "")),
        ).props("dense flat no-wrap").classes("audion-action audion-operation-button rounded-lg")
        ui.label(op_text(operation_id, "description")).classes("audion-operation-description")


def set_active_module(module_id: str) -> None:
    state["active_module"] = module_id
    if module_id == "root":
        state["command_screen"] = "main"
        state["crop_pdf_screen"] = "main"
        state["add_pdf_screen"] = "main"
    elif module_id == "conversion":
        state["command_screen"] = "convert_custom"
    elif module_id == "crop_pdf":
        state["crop_pdf_screen"] = "main"
    elif module_id == "crop_pptx":
        state["crop_pdf_screen"] = "pptx"
    elif module_id == "crop_manual":
        state["crop_pdf_screen"] = "manual"
    elif module_id == "add_pdf":
        state["add_pdf_screen"] = "main"
    elif module_id == "page_numbers":
        state["add_pdf_screen"] = "page_numbers"
    elif module_id == "scale_pdf":
        state["add_pdf_screen"] = "scale"
    operations_area.refresh()


def set_command_screen(screen: str) -> None:
    state["command_screen"] = screen
    operations_area.refresh()


def set_crop_pdf_screen(screen: str) -> None:
    state["crop_pdf_screen"] = screen
    state["active_module"] = "root" if screen == "main" else "crop_pdf"
    operations_area.refresh()


def set_add_pdf_screen(screen: str) -> None:
    state["add_pdf_screen"] = screen
    state["active_module"] = "root" if screen == "main" else "add_pdf"
    operations_area.refresh()


def command_row(label: str, description: str, on_click: Any) -> None:
    with ui.element("div").classes("audion-operation-row"):
        ui.button(label, on_click=on_click).props("dense flat no-wrap").classes("audion-action audion-operation-button rounded-lg")
        ui.label(description).classes("audion-operation-description")


def module_description(module_id: str) -> str:
    ru = settings["language"] == "ru"
    descriptions = {
        "conversion": (
            "Конвертировать Office-файлы из input или выбранной папки с фильтром форматов и постобработкой.",
            "Convert Office files from input or a chosen folder with format filters and post-processing.",
        ),
        "crop_pdf": (
            "Внутри выберите сценарий: обрезка презентационных PDF или ручная обработка PDF. Вход: input, результат: output.",
            "Choose a scenario inside: PowerPoint PDF crop or manual PDF processing. Input: input, result: output.",
        ),
        "crop_pptx": (
            "Обрезать PDF, полученные из PowerPoint, до точных 16:9. Вход: output, результат обновляется там же.",
            "Crop PowerPoint-exported PDFs to exact 16:9. Input: output, results are updated there.",
        ),
        "crop_manual": (
            "Разрезать PDF 50/50, кадрировать под 16:9/A4/A3 или обрезать поля. Вход: input, результат: output.",
            "Split PDFs 50/50, crop to 16:9/A4/A3, or crop margins. Input: input, result: output.",
        ),
        "add_pdf": (
            "Внутри выберите сценарий: нумерация страниц или уменьшение содержимого PDF. Вход: input, результат: output.",
            "Choose a scenario inside: page numbering or PDF content scaling. Input: input, result: output.",
        ),
        "page_numbers": (
            "Добавить колонтитул с номерами страниц в PDF из input и сохранить результат в output.",
            "Add page number footer/header to PDFs from input and save results to output.",
        ),
        "scale_pdf": (
            "Уменьшить содержимое страниц PDF без изменения размера страницы. Вход: input, результат: output.",
            "Scale PDF page contents without changing page size. Input: input, result: output.",
        ),
    }
    pair = descriptions[module_id]
    return pair[0] if ru else pair[1]


def child_header(title: str, on_back: Any, run_handler: Any | None = None) -> None:
    with ui.row().classes("w-full items-center gap-2 pb-1"):
        ui.button(tr("back"), on_click=on_back).props("dense flat no-wrap").classes("audion-action w-28 rounded-lg")
        ui.label(title).classes("min-w-0 flex-1 truncate text-base font-semibold text-center")
        if run_handler is None:
            ui.element("div").classes("w-28")
        else:
            ui.button(tr("run"), on_click=run_handler).props("dense color=primary no-wrap").classes("w-28 rounded-lg")


def adjusted_number_control_value(
    current: Any,
    default: Any,
    minimum: Any,
    maximum: Any,
    step_raw: Any,
    direction: int,
) -> int | float:
    try:
        step = float(step_raw)
    except (TypeError, ValueError):
        step = 1.0
    try:
        value = float(current if current not in {None, ""} else default if default not in {None, ""} else 0)
    except (TypeError, ValueError):
        value = 0.0

    value += step * (1 if direction > 0 else -1)
    for bound, clamp in ((minimum, max), (maximum, min)):
        if bound is None or bound == "":
            continue
        try:
            value = clamp(value, float(bound))
        except (TypeError, ValueError):
            continue
    return int(round(value)) if float(step).is_integer() else round(value, 6)


def spin_number_control(control: Any, default: Any, minimum: Any, maximum: Any, step: Any, direction: int) -> None:
    value = adjusted_number_control_value(getattr(control, "value", None), default, minimum, maximum, step, direction)
    control.set_value(value)


def audion_number(*args: Any, classes: str = "w-36", **kwargs: Any) -> Any:
    default = kwargs.get("value")
    minimum = kwargs.get("min")
    maximum = kwargs.get("max")
    step = kwargs.get("step", 1)
    control = ui.number(*args, **kwargs).props("dense outlined").classes(f"audion-number {classes}")
    with control.add_slot("append"):
        with ui.element("div").classes("audion-number-spinner"):
            ui.button(
                icon="keyboard_arrow_up",
                on_click=lambda item=control: spin_number_control(item, default, minimum, maximum, step, 1),
            ).props("dense flat round tabindex=-1").classes("audion-number-spin-button")
            ui.button(
                icon="keyboard_arrow_down",
                on_click=lambda item=control: spin_number_control(item, default, minimum, maximum, step, -1),
            ).props("dense flat round tabindex=-1").classes("audion-number-spin-button")
    return control


def collect_selected_options(groups: list[dict[str, Any]], group_controls: dict[str, dict[str, Any]]) -> dict[str, list[str]] | None:
    selected: dict[str, list[str]] = {}
    for group in groups:
        group_id = str(group["id"])
        ids = [
            choice_id
            for choice_id, checkbox in group_controls.get(group_id, {}).items()
            if bool(checkbox.value)
        ]
        if len(ids) < int(group.get("min_selected", 0) or 0):
            safe_notify(tr("no_options_selected"), type="warning")
            return None
        selected[group_id] = ids
    return selected


def render_option_groups(groups: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    group_controls: dict[str, dict[str, Any]] = {}
    for group in groups:
        group_id = str(group["id"])
        group_controls[group_id] = {}
        ui.label(localized_text(group, "title")).classes("text-sm font-semibold")
        description = localized_text(group, "description")
        if description:
            ui.label(description).classes("text-xs text-gray-400")
        with ui.element("div").classes("audion-checkbox-grid w-full pt-1"):
            for choice in group.get("choices", []):
                checkbox = ui.checkbox(
                    localized_text(choice, "label"),
                    value=bool(choice.get("default", False)),
                ).props("dense").classes("audion-checkbox-item")
                group_controls[group_id][str(choice["id"])] = checkbox
    return group_controls


def render_input_conversion_screen() -> None:
    operation_id = "batch_recursive"
    operation = OPERATIONS[operation_id]
    groups = operation.get("option_groups", [])
    with ui.column().classes("w-full gap-2"):
        async def submit() -> None:
            selected = collect_selected_options(groups, group_controls)
            if selected is None:
                return
            cmd = build_command(operation_id, "", selected)
            if str(post_crop.value or "none") != "none":
                cmd.extend(["--post-crop", str(post_crop.value)])
            if str(post_scale.value or "none") == "percent":
                cmd.extend(["--post-scale-percent", str(scale_percent.value or 98)])
            await start_raw_cli_operation(op_text(operation_id, "title"), cmd)

        child_header(op_text(operation_id, "title"), lambda: set_command_screen("main"), submit)
        ui.label(op_text(operation_id, "description")).classes("text-sm text-gray-300")
        group_controls = render_option_groups(groups)
        ui.label(tr("post_crop")).classes("text-sm font-semibold")
        post_crop = ui.radio(
            {"none": tr("aspect_none"), "16:9": tr("aspect_16_9"), "a-series": tr("aspect_a_series")},
            value="none",
        ).props("inline dense")
        ui.label(tr("post_scale")).classes("text-sm font-semibold")
        post_scale = ui.radio(
            {"none": tr("scale_none"), "percent": tr("scale_percent")},
            value="none",
        ).props("inline dense")
        scale_percent = audion_number(tr("scale_percent_field"), value=98, min=1, max=100, step=0.5, classes="w-36")


def render_custom_conversion_screen() -> None:
    operation = OPERATIONS["batch_recursive"]
    groups = operation.get("option_groups", [])
    with ui.column().classes("w-full gap-3"):
        async def submit() -> None:
            selected = collect_selected_options(groups, group_controls)
            if selected is None:
                return
            percent = float(scale_percent.value or 98) if str(post_scale.value or "none") == "percent" else 100.0
            source_value = str(source_input.value or "").strip() or str(FOLDERS["input"])
            destination_value = str(destination_input.value or "").strip() or str(FOLDERS["output"])
            await start_convert_operation(
                source_value,
                destination_value,
                selected,
                str(post_crop.value or "none"),
                percent,
            )

        child_header(tr("convert_setup"), lambda: set_active_module("root"), submit)

        with ui.column().classes("audion-panel w-full gap-2 p-3"):
            cache_label = ui.label(
                tr("cache_ready", count=int(state.get("convert_cache_count") or 0))
                if int(state.get("convert_cache_count") or 0)
                else tr("cache_empty")
            ).classes("text-xs text-gray-400")
            with ui.row().classes("w-full items-center gap-2"):
                source_input = ui.input(tr("source_folder"), placeholder=str(FOLDERS["input"])).props("dense outlined").classes("min-w-0 flex-1")
                ui.button(tr("add"), on_click=lambda: choose_folder_into(source_input, tr("source_folder"))).props("dense flat no-wrap").classes("audion-action w-32 rounded-lg")
            with ui.row().classes("w-full items-center gap-2"):
                destination_input = ui.input(tr("destination_folder"), placeholder=str(FOLDERS["output"])).props("dense outlined").classes("min-w-0 flex-1")
                ui.button(tr("add"), on_click=lambda: choose_folder_into(destination_input, tr("destination_folder"))).props("dense flat no-wrap").classes("audion-action w-32 rounded-lg")

            with ui.row().classes("w-full flex-wrap justify-center gap-2 pt-1"):
                ui.button(tr("add_files"), on_click=lambda: add_to_convert_cache("files", source_input, cache_label)).props("dense flat no-wrap").classes("audion-action w-44 rounded-lg")
                ui.button(tr("add_folders"), on_click=lambda: add_to_convert_cache("folder", source_input, cache_label)).props("dense flat no-wrap").classes("audion-action w-44 rounded-lg")
                ui.button(tr("target_folder"), on_click=lambda: choose_folder_into(destination_input, tr("target_folder"))).props("dense flat no-wrap").classes("audion-action w-44 rounded-lg")

        with ui.column().classes("audion-panel w-full gap-2 p-3"):
            group_controls = render_option_groups(groups)

        with ui.column().classes("audion-panel w-full gap-3 p-3"):
            with ui.element("div").classes("audion-post-grid w-full"):
                with ui.column().classes("audion-post-cell gap-2"):
                    ui.label(tr("post_crop")).classes("text-sm font-semibold text-center")
                    with ui.row().classes("audion-radio-row w-full"):
                        post_crop = ui.radio(
                            {"none": tr("aspect_none"), "16:9": tr("aspect_16_9"), "a-series": tr("aspect_a_series")},
                            value="none",
                        ).props("inline dense").classes("audion-radio")
                with ui.column().classes("audion-post-cell gap-2"):
                    ui.label(tr("post_scale")).classes("text-sm font-semibold text-center")
                    with ui.row().classes("audion-radio-row w-full"):
                        post_scale = ui.radio(
                            {"none": tr("scale_none"), "percent": tr("scale_percent")},
                            value="none",
                        ).props("inline dense").classes("audion-radio")
                    with ui.row().classes("w-full justify-center"):
                        scale_percent = audion_number(tr("scale_percent_field"), value=98, min=1, max=100, step=0.5, classes="w-36")


@ui.refreshable
def command_area() -> None:
    screen = str(state.get("command_screen") or "main")
    if screen in {"main", "convert_custom"}:
        render_custom_conversion_screen()
        return
    if screen == "convert_input":
        render_input_conversion_screen()
        return


@ui.refreshable
def crop_pdf_area() -> None:
    screen = str(state.get("crop_pdf_screen") or "main")
    if screen == "pptx":
        with ui.column().classes("w-full gap-2"):
            async def submit_pptx_crop() -> None:
                operation_id = "crop_pptx_force" if bool(repeat_crop.value) else "crop_pptx"
                await start_operation(operation_id)

            child_header(tr("crop_pptx_setup"), lambda: set_active_module("root"), submit_pptx_crop)
            ui.label(op_text("crop_pptx", "description")).classes("text-sm text-gray-300")
            with ui.column().classes("audion-panel w-full gap-2 p-3"):
                repeat_crop = ui.checkbox(tr("repeat_crop"), value=False).props("dense").classes("audion-checkbox-item")
        return

    if screen == "manual":
        with ui.column().classes("w-full gap-2"):
            async def submit_manual_crop() -> None:
                mode = str(action_mode.value or "split_vertical")
                if mode == "split_vertical":
                    command = [sys.executable, "-u", str(MAIN_PY), "pdf-split", "--orientation", "vertical"]
                    if bool(skip_cover.value):
                        command.append("--skip-cover")
                    await start_raw_cli_operation(
                        tr("split_vertical"),
                        command,
                    )
                    return
                if mode == "split_horizontal":
                    command = [sys.executable, "-u", str(MAIN_PY), "pdf-split", "--orientation", "horizontal"]
                    if bool(skip_cover.value):
                        command.append("--skip-cover")
                    await start_raw_cli_operation(
                        tr("split_horizontal"),
                        command,
                    )
                    return
                if mode == "aspect_16_9":
                    await start_raw_cli_operation(
                        tr("aspect_crop"),
                        [sys.executable, "-u", str(MAIN_PY), "pdf-crop-aspect", "--mode", "16:9"],
                    )
                    return
                if mode == "aspect_a_series":
                    await start_raw_cli_operation(
                        tr("aspect_crop"),
                        [sys.executable, "-u", str(MAIN_PY), "pdf-crop-aspect", "--mode", "a-series"],
                    )
                    return
                await start_raw_cli_operation(
                    tr("crop_margins"),
                    [
                        sys.executable,
                        "-u",
                        str(MAIN_PY),
                        "pdf-crop-margins",
                        "--left-mm",
                        str(left.value or 0),
                        "--right-mm",
                        str(right.value or 0),
                        "--top-mm",
                        str(top.value or 0),
                        "--bottom-mm",
                        str(bottom.value or 0),
                    ],
                )

            child_header(tr("crop_pdf_manual_setup"), lambda: set_active_module("root"), submit_manual_crop)
            with ui.column().classes("audion-panel w-full gap-2 p-3"):
                ui.label(tr("pdf_crop_action")).classes("text-sm font-semibold text-center")
                action_options = {
                    "split_vertical": tr("split_vertical"),
                    "split_horizontal": tr("split_horizontal"),
                    "aspect_16_9": tr("aspect_16_9"),
                    "aspect_a_series": tr("aspect_a_series"),
                    "margins": tr("crop_margins"),
                }
                with ui.row().classes("audion-radio-row w-full"):
                    action_mode = ui.radio(action_options, value="split_vertical").props("inline dense").classes("audion-radio")
                with ui.row().classes("w-full justify-center"):
                    skip_cover = ui.checkbox(tr("skip_cover"), value=False).props("dense").classes("audion-checkbox-item")
                ui.label(tr("skip_cover_hint")).classes("text-xs text-gray-400 text-center")
            with ui.column().classes("audion-panel w-full gap-2 p-3"):
                ui.label(tr("crop_margins")).classes("text-sm font-semibold")
                with ui.row().classes("w-full flex-wrap gap-2"):
                    left = audion_number(tr("left_mm"), value=0, min=0, step=1, classes="w-32")
                    right = audion_number(tr("right_mm"), value=0, min=0, step=1, classes="w-32")
                    top = audion_number(tr("top_mm"), value=0, min=0, step=1, classes="w-32")
                    bottom = audion_number(tr("bottom_mm"), value=0, min=0, step=1, classes="w-32")
        return

    with ui.column().classes("w-full gap-2"):
        child_header(tr("crop_pdf_setup"), lambda: set_active_module("root"))
        command_row(
            tr("crop_pptx_setup"),
            op_text("crop_pptx", "description"),
            lambda: set_crop_pdf_screen("pptx"),
        )
        command_row(
            tr("crop_pdf_manual_setup"),
            "Разрезать PDF 50/50, кадрировать под 16:9/A4/A3 или обрезать поля. Вход: input, результат: output."
            if settings["language"] == "ru"
            else "Split PDFs 50/50, crop to 16:9/A4/A3, or crop margins. Input: input, result: output.",
            lambda: set_crop_pdf_screen("manual"),
        )


@ui.refreshable
def add_pdf_area() -> None:
    screen = str(state.get("add_pdf_screen") or "main")
    if screen == "page_numbers":
        with ui.column().classes("w-full gap-2"):
            async def submit_page_numbers() -> None:
                await start_raw_cli_operation(
                    tr("page_numbers"),
                    [
                        sys.executable,
                        "-u",
                        str(MAIN_PY),
                        "pdf-page-numbers",
                        "--start-page",
                        str(int(start_page.value or 1)),
                        "--start-number",
                        str(int(start_number.value or 1)),
                        "--offset-mm",
                        str(offset.value or 0),
                        "--position",
                        str(position.value or "bottom-right"),
                    ],
                )

            child_header(tr("page_numbers_setup"), lambda: set_active_module("root"), submit_page_numbers)
            with ui.column().classes("audion-panel w-full gap-2 p-3"):
                ui.label(tr("page_numbers")).classes("text-sm font-semibold")
                with ui.row().classes("w-full flex-wrap gap-2"):
                    start_page = audion_number(tr("start_page"), value=1, min=1, step=1, classes="w-40")
                    start_number = audion_number(tr("start_number"), value=1, min=0, step=1, classes="w-40")
                    offset = audion_number(tr("offset_mm"), value=10, min=0, step=1, classes="w-40")
                    position = ui.select(
                        page_number_position_options(),
                        value="bottom-right",
                        label=tr("position"),
                    ).props("dense outlined popup-content-class=audion-select-popup").classes("audion-select w-52")
        return

    if screen == "scale":
        with ui.column().classes("w-full gap-2"):
            async def submit_scale_pdf_content() -> None:
                await start_raw_cli_operation(
                    tr("scale_pdf_content"),
                    [
                        sys.executable,
                        "-u",
                        str(MAIN_PY),
                        "pdf-scale-content",
                        "--percent",
                        str(pdf_scale_percent.value or 98),
                    ],
                )

            child_header(tr("scale_pdf_setup"), lambda: set_active_module("root"), submit_scale_pdf_content)
            with ui.column().classes("audion-panel w-full gap-2 p-3"):
                ui.label(tr("scale_pdf_content")).classes("text-sm font-semibold")
                with ui.row().classes("w-full flex-wrap justify-center gap-2"):
                    pdf_scale_percent = audion_number(tr("scale_percent_field"), value=98, min=1, max=100, step=0.5, classes="w-36")
        return

    with ui.column().classes("w-full gap-2"):
        child_header(tr("add_pdf_setup"), lambda: set_active_module("root"))
        command_row(
            tr("page_numbers_setup"),
            "Добавить колонтитул с номерами страниц в PDF из input и сохранить результат в output."
            if settings["language"] == "ru"
            else "Add page number footer/header to PDFs from input and save results to output.",
            lambda: set_add_pdf_screen("page_numbers"),
        )
        command_row(
            tr("scale_pdf_setup"),
            "Уменьшить содержимое страниц PDF без изменения размера страницы. Вход: input, результат: output."
            if settings["language"] == "ru"
            else "Scale PDF page contents without changing page size. Input: input, result: output.",
            lambda: set_add_pdf_screen("scale"),
        )


@ui.refreshable
def operations_area() -> None:
    active_module = str(state.get("active_module") or "root")
    crop_ids = [operation_id for operation_id in MAIN_OPERATION_IDS if operation_id.startswith("crop_")]
    utility_ids = [
        operation_id
        for operation_id in MAIN_OPERATION_IDS
        if operation_id != "batch_recursive" and operation_id not in crop_ids
    ]

    if active_module == "conversion":
        with ui.column().classes("w-full gap-3"):
            command_area()
        return

    if active_module in {"crop_pdf", "crop_pptx", "crop_manual"}:
        with ui.column().classes("w-full gap-3"):
            crop_pdf_area()
        return

    if active_module in {"add_pdf", "page_numbers", "scale_pdf"}:
        with ui.column().classes("w-full gap-3"):
            add_pdf_area()
        return

    with ui.column().classes("audion-panel w-full gap-1 p-3"):
        command_row(tr("conversion_group"), module_description("conversion"), lambda: set_active_module("conversion"))
        command_row(tr("crop_pptx_setup"), module_description("crop_pptx"), lambda: set_active_module("crop_pptx"))
        command_row(tr("crop_pdf_manual_setup"), module_description("crop_manual"), lambda: set_active_module("crop_manual"))
        command_row(tr("page_numbers_setup"), module_description("page_numbers"), lambda: set_active_module("page_numbers"))
        command_row(tr("scale_pdf_setup"), module_description("scale_pdf"), lambda: set_active_module("scale_pdf"))

    for operation_id in utility_ids:
        operation_button(operation_id)


def folder_button(folder_id: str) -> None:
    folder = FOLDERS[folder_id]
    with ui.row().classes("w-full items-center gap-3"):
        ui.button(folder_id, on_click=lambda item=folder_id: open_folder(item)).props("dense flat no-wrap").classes("audion-action w-20 rounded-lg")
        ui.label(str(folder)).classes("min-w-0 flex-1 truncate font-mono text-xs text-gray-300")


def toggle_language() -> None:
    settings["language"] = "en" if settings["language"] == "ru" else "ru"
    save_settings()
    ui.run_javascript("window.location.reload()")


def build_ui() -> None:
    ensure_dirs()
    load_settings()
    if not state["status"]:
        state["status"] = tr("idle")
    if active_theme_mode() == "dark":
        ui.dark_mode().enable()
    else:
        ui.dark_mode().disable()

    variables_css = "\n".join(
        f"  --{key}: {value};"
        for key, value in sorted(theme_variables().items())
    )
    ui.add_head_html(
        (
            "<style>\n"
            ":root {\n"
            f"{variables_css}\n"
            "  --audion-bg: var(--color-background-tertiary);\n"
            "  --audion-header-bg: var(--color-background-primary);\n"
            "  --audion-header-text: var(--color-text-primary);\n"
            "  --audion-panel-bg: var(--color-background-secondary);\n"
            "  --audion-terminal-bg: var(--color-background-tertiary);\n"
            "  --audion-text: var(--color-text-primary);\n"
            "  --audion-secondary-text: var(--color-text-secondary);\n"
            "  --audion-muted-text: var(--color-text-tertiary);\n"
            "  --audion-button-text: var(--color-accent-primary);\n"
            "  --audion-button-hover-bg: var(--color-background-primary);\n"
            "  --audion-button-hover-background: var(--audion-button-hover-bg);\n"
            "  --audion-panel-border: color-mix(in srgb, var(--color-border-tertiary) 62%, transparent 38%);\n"
            "  --audion-divider: color-mix(in srgb, var(--color-border-tertiary) 48%, transparent 52%);\n"
            "  --audion-button-hover-border: var(--audion-input-border-hover);\n"
            "  --audion-border: var(--audion-panel-border);\n"
            "  --audion-strong-border: var(--audion-input-border-hover);\n"
            "  --audion-input-border: color-mix(in srgb, var(--color-border-secondary) 54%, transparent 46%);\n"
            "  --audion-input-border-hover: color-mix(in srgb, var(--color-border-secondary) 72%, transparent 28%);\n"
            "  --audion-input-border-focus: color-mix(in srgb, var(--color-accent-primary) 78%, var(--color-border-secondary) 22%);\n"
            "  --audion-terminal-border: var(--audion-panel-border);\n"
            "  --audion-gui-font: var(--font-sans);\n"
            "  --audion-terminal-font: var(--font-mono);\n"
            "  --audion-button-size: 13px;\n"
            "  --audion-terminal-size: 12px;\n"
            "  --audion-terminal-line-height: 1.35;\n"
            "}\n"
            "</style>\n"
        )
    )

    ui.add_head_html(
        """
        <style>
          body {
            background: var(--audion-bg);
            color: var(--audion-text);
            font-family: var(--audion-gui-font);
            overflow: hidden;
          }
          .nicegui-content { padding: 0; height: 100vh; overflow: hidden; }
          .q-layout,
          .q-page,
          .nicegui-content {
            background: var(--audion-bg) !important;
            color: var(--audion-text) !important;
          }
          .q-textarea textarea { min-height: 0 !important; }
          .audion-header {
            background: var(--audion-header-bg) !important;
            border-bottom: 1px solid var(--audion-divider);
            color: var(--audion-header-text) !important;
          }
          .audion-header-controls {
            align-items: center !important;
            transform: translateY(-11px);
          }
          .audion-header-title {
            transform: translateY(-11px);
          }
          .audion-theme-select {
            width: 168px;
            min-height: 32px !important;
            height: 32px !important;
          }
          .audion-theme-select.q-field,
          .audion-theme-select .q-field__inner {
            min-height: 32px !important;
            height: 32px !important;
            padding-bottom: 0 !important;
          }
          .audion-theme-select .q-field__control {
            min-height: 32px !important;
            height: 32px !important;
            background: transparent !important;
            padding: 0 8px 0 14px !important;
            border-radius: var(--border-radius-md) !important;
          }
          .audion-theme-select .q-field__marginal,
          .audion-theme-select .q-field__native,
          .audion-theme-select .q-field__append {
            min-height: 32px !important;
            height: 32px !important;
            color: var(--audion-button-text) !important;
            font-size: 13px !important;
          }
          .audion-theme-select .q-field__native {
            align-items: center !important;
            line-height: 32px !important;
            padding: 0 0 1px 0 !important;
          }
          .audion-theme-select .q-field__control::before {
            border-color: var(--audion-input-border) !important;
          }
          .audion-theme-select .q-field__bottom {
            display: none !important;
          }
          .audion-shell .text-gray-300,
          .audion-shell .text-gray-400,
          .audion-shell .text-gray-500,
          .audion-dialog .text-gray-300,
          .audion-dialog .text-gray-400,
          .audion-dialog .text-gray-500 {
            color: var(--audion-secondary-text) !important;
          }
          .q-field__native,
          .q-field__input,
          .q-field input,
          .q-checkbox__label,
          .q-radio__label {
            color: var(--audion-text) !important;
          }
          .audion-button {
            min-height: 30px !important;
            height: 30px !important;
            padding-left: 10px !important;
            padding-right: 10px !important;
            color: var(--audion-button-text) !important;
            background: transparent !important;
            border: 1px solid transparent !important;
          }
          .audion-button:hover {
            background: var(--audion-button-hover-bg) !important;
            border-color: var(--audion-button-hover-border) !important;
          }
          .audion-button .q-btn__content {
            width: 100%;
            flex-wrap: nowrap !important;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-size: var(--audion-button-size);
            line-height: 1;
          }
          .audion-action {
            min-height: 30px !important;
            height: 30px !important;
            padding-left: 10px !important;
            padding-right: 10px !important;
            color: var(--audion-button-text) !important;
            background: transparent !important;
            border: 1px solid transparent !important;
          }
          .audion-action:hover {
            background: var(--audion-button-hover-bg) !important;
            border-color: var(--audion-button-hover-border) !important;
          }
          .audion-action .q-btn__content {
            width: 100%;
            justify-content: center;
            flex-wrap: nowrap !important;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-size: var(--audion-button-size);
            line-height: 1;
          }
          .audion-operation-row {
            display: grid;
            grid-template-columns: 220px minmax(0, 1fr);
            gap: 16px;
            align-items: center;
            width: 100%;
            min-width: 0;
            border-bottom: 1px solid var(--audion-divider);
            padding: 8px 0;
            overflow: visible;
          }
          .audion-operation-button {
            width: 220px !important;
            min-width: 220px !important;
            max-width: 220px !important;
            justify-self: start;
            padding-left: 12px !important;
            padding-right: 12px !important;
          }
          .audion-operation-button .q-btn__content {
            justify-content: flex-start !important;
            text-align: left !important;
            min-width: 0 !important;
            width: 100% !important;
            max-width: 100% !important;
            overflow: hidden !important;
            flex-wrap: nowrap !important;
          }
          .audion-operation-button .q-btn__content > span,
          .audion-operation-button .q-btn__content > div {
            display: block !important;
            min-width: 0 !important;
            max-width: 100% !important;
            overflow: hidden !important;
            text-overflow: ellipsis !important;
            white-space: nowrap !important;
            text-align: left !important;
          }
          .audion-operation-description {
            min-width: 0;
            color: var(--audion-secondary-text);
            font-size: 14px;
            line-height: 1.35;
            white-space: normal;
            overflow-wrap: anywhere;
          }
          .audion-shell {
            display: grid;
            grid-template-columns: minmax(520px, 58%) minmax(360px, 42%);
            gap: 12px;
            width: 100vw;
            max-width: none;
            height: calc(100vh - 42px);
            padding: 12px;
            overflow: hidden;
          }
          .audion-pane {
            min-height: 0;
            overflow: hidden;
          }
          .audion-scroll {
            min-height: 0;
            overflow: auto;
          }
          .audion-right {
            display: grid;
            grid-template-rows: auto minmax(66vh, 1fr);
            min-height: 0;
            height: 100%;
            overflow: hidden;
          }
          .audion-panel {
            background: var(--audion-panel-bg);
            border: 1px solid var(--audion-panel-border);
            border-radius: 8px;
          }
          .audion-checkbox-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(88px, 1fr));
            gap: 10px 14px;
            align-items: center;
          }
          .audion-checkbox-item {
            min-width: 0;
          }
          .audion-checkbox-item .q-checkbox__label {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          }
          .audion-post-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(260px, 1fr));
            gap: 14px;
            align-items: start;
          }
          .audion-post-cell {
            min-width: 0;
            padding: 4px 6px;
          }
          .audion-radio-row {
            justify-content: center;
          }
          .audion-radio .q-option-group {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 8px 16px;
          }
          .audion-number .q-field__control,
          .audion-select .q-field__control {
            min-height: 38px !important;
            background: var(--audion-terminal-bg) !important;
            border-radius: var(--border-radius-md) !important;
          }
          .audion-number .q-field__marginal,
          .audion-number .q-field__append,
          .audion-select .q-field__marginal,
          .audion-select .q-field__append {
            min-height: 38px !important;
            height: 38px !important;
            display: flex !important;
            align-items: center !important;
            align-self: center !important;
            padding-top: 0 !important;
            padding-bottom: 0 !important;
          }
          .audion-number .q-field__append .q-icon,
          .audion-select .q-field__append .q-icon,
          .audion-theme-select .q-field__append .q-icon {
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            height: 100% !important;
            line-height: 1 !important;
            transform: translateY(-1px);
          }
          .audion-number input[type="number"]::-webkit-inner-spin-button,
          .audion-number input[type="number"]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
          }
          .audion-number input[type="number"] {
            appearance: textfield;
            -moz-appearance: textfield;
          }
          .audion-number-spinner {
            width: 18px;
            height: 24px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 0;
            margin-right: -2px;
          }
          .audion-number-spin-button {
            width: 18px !important;
            min-width: 18px !important;
            height: 12px !important;
            min-height: 12px !important;
            padding: 0 !important;
            border-radius: 3px !important;
            color: var(--audion-button-text) !important;
            opacity: 0.92;
          }
          .audion-number-spin-button:hover {
            opacity: 1;
            color: var(--audion-button-text) !important;
            background: var(--audion-button-hover-background) !important;
          }
          .audion-number-spin-button .q-icon {
            font-size: 13px !important;
            line-height: 1 !important;
          }
          .audion-number .q-field__native,
          .audion-number input,
          .audion-select .q-field__native,
          .audion-select .q-field__input,
          .audion-select input {
            font-size: 13px !important;
          }
          .audion-select .q-field__input,
          .audion-select input {
            caret-color: transparent !important;
          }
          .audion-number.q-field--outlined .q-field__control:before,
          .audion-number.q-field--outlined .q-field__control:after,
          .audion-select.q-field--outlined .q-field__control:before,
          .audion-select.q-field--outlined .q-field__control:after {
            border-style: solid !important;
            border-color: var(--audion-input-border) !important;
          }
          .audion-number.q-field--outlined.q-field--focused .q-field__control:after,
          .audion-select.q-field--outlined.q-field--focused .q-field__control:after {
            border-color: var(--audion-input-border-focus) !important;
          }
          .audion-number.q-field--outlined:hover .q-field__control:before,
          .audion-select.q-field--outlined:hover .q-field__control:before {
            border-color: var(--audion-input-border-hover) !important;
          }
          .audion-select-popup {
            min-width: min(720px, calc(100vw - 48px)) !important;
            max-width: min(900px, calc(100vw - 32px)) !important;
            background: var(--audion-panel-bg) !important;
            border: 1px solid var(--audion-panel-border) !important;
            box-shadow: 0 12px 28px rgba(0, 0, 0, 0.32) !important;
          }
          .audion-select-popup .q-item__label {
            white-space: normal;
            line-height: 1.25;
          }
          .audion-terminal-panel {
            display: flex;
            flex-direction: column;
            background: var(--audion-terminal-bg);
            border: 1px solid var(--audion-terminal-border);
            border-radius: 8px;
            min-height: 0;
            height: 100%;
            overflow: hidden;
          }
          .audion-terminal {
            flex: 1 1 auto;
            min-height: 0;
            height: 100% !important;
            background: var(--audion-terminal-bg) !important;
          }
          .audion-terminal .q-field__control {
            height: 100% !important;
            background: var(--audion-terminal-bg) !important;
            border-color: var(--audion-input-border) !important;
          }
          .audion-terminal textarea {
            height: 100% !important;
            resize: none !important;
            color: var(--audion-muted-text) !important;
            font-family: var(--audion-terminal-font) !important;
            font-size: var(--audion-terminal-size) !important;
            line-height: var(--audion-terminal-line-height) !important;
            background: var(--audion-terminal-bg) !important;
          }
          .audion-terminal-footer {
            flex: 0 0 auto;
            min-height: 26px;
            border-top: 1px solid var(--audion-divider);
            color: var(--audion-muted-text);
          }
          .audion-terminal-expanded {
            height: calc(100vh - 96px) !important;
          }
          @media (max-width: 900px) {
            body { overflow: auto; }
            .nicegui-content { height: auto; overflow: visible; }
            .audion-shell {
              display: flex;
              flex-direction: column;
              height: auto;
              overflow: visible;
            }
            .audion-post-grid {
              grid-template-columns: 1fr;
            }
          }
        </style>
        """
    )

    with ui.header().classes("audion-header h-[42px] items-center justify-between px-4"):
        ui.label("Audion Doc to PDF").classes("audion-header-title text-lg font-bold")
        with ui.row().classes("audion-header-controls items-center gap-2"):
            ui.icon("palette").classes("text-lg")
            ui.select(
                options=theme_options(),
                value=active_theme(),
                on_change=theme_change_handler,
            ).props("dense outlined options-dense").classes("audion-theme-select")
            ui.button(tr("lang_switch"), on_click=toggle_language).props("dense flat").classes("audion-button rounded-lg")
            cancel_button = ui.button(tr("cancel"), on_click=lambda: state.update({"cancel": True})).props("dense flat color=negative")
            cancel_button.visible = False

    with ui.element("div").classes("audion-shell"):
        with ui.column().classes("audion-pane audion-scroll gap-3"):
            with ui.column().classes("audion-panel w-full gap-1 p-3"):
                ui.label(f"{em('workspace')}{tr('workspace')}").classes("text-base font-semibold")
                with ui.row().classes("w-full items-center gap-2 pb-1"):
                    ui.button(tr("add_files"), on_click=lambda: start_import("files")).props("dense flat no-wrap").classes("audion-action w-44 rounded-lg")
                    ui.button(tr("add_folder"), on_click=lambda: start_import("folder")).props("dense flat no-wrap").classes("audion-action w-44 rounded-lg")
                    ui.button(tr("clear_io"), on_click=confirm_cleanup_input_output).props("dense flat no-wrap").classes("audion-action w-36 rounded-lg")
                folder_button("input")
                folder_button("output")

            ui.label(f"{em('operations')}{tr('operations')}").classes("text-lg font-bold")
            operations_area()

        with ui.element("div").classes("audion-pane audion-right gap-2 pt-3"):
            with ui.column().classes("audion-panel w-full gap-2 p-3"):
                with ui.row().classes("w-full items-center gap-3"):
                    ui.label(f"{em('status')}{tr('status')}").classes("text-base font-semibold")
                    status_label = ui.label(str(state["status"])).classes("min-w-0 flex-1 text-sm text-gray-300")
                with ui.row().classes("w-full items-center gap-3"):
                    progress = ui.linear_progress(value=0.0, show_value=False).classes("min-w-0 flex-1")
                    progress_label = ui.label(progress_text()).classes("w-12 text-right text-sm text-gray-300")

            with ui.column().classes("audion-terminal-panel w-full gap-2 p-3"):
                with ui.row().classes("w-full items-center gap-2"):
                    ui.label(f"{em('log')}{tr('log')}").classes("text-base font-semibold")
                    ui.space()
                    ui.button("Logs", on_click=lambda: open_folder("logs")).props("dense flat").classes("audion-button rounded-lg")
                    ui.button("CONFIG", on_click=lambda: open_folder("config")).props("dense flat").classes("audion-button rounded-lg")
                    ui.button(tr("report"), on_click=lambda: open_folder("report")).props("dense flat").classes("audion-button rounded-lg")
                    ui.button(tr("expand_log"), on_click=lambda: log_dialog.open()).props("dense flat").classes("audion-button rounded-lg")
                log_view = ui.textarea(value="").props("readonly dense outlined").classes("audion-terminal w-full min-h-[66vh]")
                with ui.row().classes("audion-terminal-footer w-full items-center gap-2 px-1 pt-1"):
                    status_dot = ui.label("●").classes(status_dot_classes())
                    terminal_status_label = ui.label(str(state["status"])).classes("min-w-0 flex-1 truncate text-xs")

    with ui.dialog() as log_dialog:
        with ui.card().classes("h-[92vh] w-[92vw] rounded-lg p-3").style("background: var(--audion-terminal-bg);"):
            with ui.row().classes("w-full items-center gap-2"):
                ui.label(f"{em('log')}{tr('log')}").classes("text-base font-semibold")
                ui.space()
                ui.button(tr("close"), on_click=log_dialog.close).props("dense flat").classes("audion-button rounded-lg")
            expanded_log_view = ui.textarea(value="").props("readonly dense outlined").classes("audion-terminal audion-terminal-expanded w-full")

    last_log_version = {"value": -1}
    refresh_timer: Any | None = None

    def refresh() -> None:
        nonlocal refresh_timer
        try:
            status_label.text = str(state["status"])
            status_dot.classes(replace=status_dot_classes())
            terminal_status_label.text = str(state["status"])
            progress.value = float(state["progress"])
            progress_label.text = progress_text()
            log_version = int(state["log_version"])
            if log_version != last_log_version["value"]:
                last_log_version["value"] = log_version
                log_text = "\n".join(state["lines"])
                log_view.value = log_text
                expanded_log_view.value = log_text
                ui.run_javascript(
                    """
                    requestAnimationFrame(() => {
                      document.querySelectorAll('.audion-terminal textarea').forEach((el) => {
                        el.scrollTop = el.scrollHeight;
                      });
                    });
                    """
                )
            cancel_button.visible = bool(state["running"])
        except RuntimeError as exc:
            if "slot belongs to has been deleted" not in str(exc):
                raise
            logging.warning("NiceGUI refresh timer stopped because the client slot was deleted.")
            if refresh_timer is not None:
                refresh_timer.deactivate()

    refresh_timer = ui.timer(0.5, refresh)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audion Doc to PDF NiceGUI shell.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8091)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--smoke", action="store_true")
    return parser.parse_args()


def port_is_open(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.3)
        return sock.connect_ex((host, port)) == 0


def main() -> int:
    args = parse_args()
    ensure_dirs()
    if args.smoke:
        print(f"OK nicegui shell: {ROOT}")
        return 0

    if port_is_open(args.host, args.port):
        url = f"http://{args.host}:{args.port}/"
        print(f"Audion Doc to PDF GUI already appears to be running: {url}")
        if not args.no_browser:
            webbrowser.open(url)
        return 0

    ui.run(
        root=build_ui,
        title="Audion Doc to PDF",
        host=args.host,
        port=args.port,
        reload=False,
        native=False,
        show=not args.no_browser,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
